import React from 'react';
import { Share2, Download } from 'lucide-react';
import type { AgeData } from '../types';

interface ActionButtonsProps {
  ageData: AgeData;
  onShare: () => void;
}

export function ActionButtons({ ageData, onShare }: ActionButtonsProps) {
  return (
    <div className="flex flex-wrap gap-4 justify-center">
      <button
        onClick={onShare}
        className="action-button bg-blue-500 hover:bg-blue-600 transform hover:scale-105 transition-all"
      >
        <Share2 className="w-5 h-5" />
        Share Results
      </button>
      <button
        onClick={() => window.print()}
        className="action-button bg-green-500 hover:bg-green-600 transform hover:scale-105 transition-all"
      >
        <Download className="w-5 h-5" />
        Save Report
      </button>
    </div>
  );
}