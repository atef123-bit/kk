import React from 'react';
import { Calendar, Clock, ArrowDown } from 'lucide-react';

export function Hero() {
  return (
    <div className="relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24">
        <div className="text-center">
          <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-pink-600 mb-8">
            Discover Your Life in Numbers
          </h1>
          <p className="max-w-2xl mx-auto text-xl text-gray-600 dark:text-gray-300 mb-8">
            More than just an age calculator. Explore fascinating insights about your life journey, from heartbeats to zodiac influences.
          </p>
          <div className="flex justify-center space-x-6 mb-12">
            <span className="inline-flex items-center text-gray-600 dark:text-gray-300">
              <Clock className="h-5 w-5 mr-2" />
              Precise Calculations
            </span>
            <span className="inline-flex items-center text-gray-600 dark:text-gray-300">
              <Calendar className="h-5 w-5 mr-2" />
              Detailed Statistics
            </span>
          </div>
          <ArrowDown className="h-8 w-8 mx-auto text-purple-600 animate-bounce" />
        </div>
      </div>
    </div>
  );
}