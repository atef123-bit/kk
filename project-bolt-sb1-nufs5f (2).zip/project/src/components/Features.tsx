import React from 'react';
import { Heart, Brain, Share2, Calendar } from 'lucide-react';

export function Features() {
  const features = [
    {
      icon: Calendar,
      title: 'Precise Age Calculation',
      description: 'Get accurate calculations down to the second with our advanced algorithm.',
    },
    {
      icon: Heart,
      title: 'Health Insights',
      description: 'Discover fascinating statistics about your heartbeats and breaths taken.',
    },
    {
      icon: Brain,
      title: 'Astrological Analysis',
      description: 'Explore your zodiac sign and its influence on your personality.',
    },
    {
      icon: Share2,
      title: 'Easy Sharing',
      description: 'Share your age statistics with friends and family instantly.',
    },
  ];

  return (
    <div className="py-16 bg-white/50 dark:bg-gray-800/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature) => (
            <div
              key={feature.title}
              className="relative p-6 bg-white dark:bg-gray-700 rounded-xl shadow-md hover:shadow-lg transition-shadow"
            >
              <div className="absolute -top-4 left-6">
                <div className="inline-flex p-3 bg-purple-600 text-white rounded-lg">
                  <feature.icon className="h-6 w-6" />
                </div>
              </div>
              <h3 className="mt-8 text-xl font-semibold text-gray-900 dark:text-white">
                {feature.title}
              </h3>
              <p className="mt-2 text-gray-600 dark:text-gray-300">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}