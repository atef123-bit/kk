import React, { useState } from 'react';
import { calculateAge, getZodiacSign } from '../utils/calculations';
import { InputSection } from './InputSection';
import { AgeDisplay } from './AgeDisplay';
import { DetailedStats } from './DetailedStats';
import { ActionButtons } from './ActionButtons';
import type { AgeData } from '../types';

export function Calculator() {
  const [birthDate, setBirthDate] = useState<string>('');
  const [ageData, setAgeData] = useState<AgeData | null>(null);
  const [showStats, setShowStats] = useState(false);

  const handleCalculateAge = () => {
    const data = calculateAge(birthDate);
    setAgeData(data);
  };

  const handleShare = () => {
    if (ageData) {
      const text = `My age: ${ageData.years} years, ${ageData.months} months, and ${ageData.days} days!`;
      if (navigator.share) {
        navigator.share({
          title: 'My Age Calculation',
          text: text,
        });
      }
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-16">
      <div className="space-y-8">
        <InputSection
          birthDate={birthDate}
          onDateChange={setBirthDate}
          onCalculate={handleCalculateAge}
        />

        {ageData && (
          <div className="space-y-8 animate-fade-in">
            <AgeDisplay ageData={ageData} />
            <DetailedStats
              ageData={ageData}
              showStats={showStats}
              onToggleStats={() => setShowStats(!showStats)}
              zodiacSign={getZodiacSign(birthDate).sign}
              lifeExpectancy={73}
            />
            <ActionButtons
              ageData={ageData}
              onShare={handleShare}
            />
          </div>
        )}
      </div>
    </div>
  );
}