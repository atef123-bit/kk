import React from 'react';
import { Calendar, Moon, Sun } from 'lucide-react';

interface HeaderProps {
  theme: 'light' | 'dark';
  onThemeToggle: () => void;
}

export function Header({ theme, onThemeToggle }: HeaderProps) {
  return (
    <div className="text-center mb-10">
      <div className="flex justify-center items-center gap-2 mb-4">
        <Calendar className="w-10 h-10 text-purple-600 animate-pulse-slow" />
        <h1 className="text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-pink-600">
          Age Calculator Pro
        </h1>
      </div>
      <button
        onClick={onThemeToggle}
        className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
        aria-label={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
      >
        {theme === 'light' ? <Moon className="w-6 h-6" /> : <Sun className="w-6 h-6" />}
      </button>
    </div>
  );
}