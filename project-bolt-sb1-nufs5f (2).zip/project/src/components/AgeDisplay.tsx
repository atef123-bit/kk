import React from 'react';
import { Cake, Calendar, Timer } from 'lucide-react';
import type { AgeData } from '../types';

interface AgeDisplayProps {
  ageData: AgeData;
}

export function AgeDisplay({ ageData }: AgeDisplayProps) {
  const cards = [
    { icon: Cake, value: ageData.years, label: 'Years', color: 'purple' },
    { icon: Calendar, value: ageData.months, label: 'Months', color: 'pink' },
    { icon: Timer, value: ageData.days, label: 'Days', color: 'blue' },
  ];

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {cards.map(({ icon: Icon, value, label, color }) => (
          <div
            key={label}
            className={`text-center p-4 bg-${color}-50 dark:bg-gray-700 rounded-lg transform hover:scale-105 transition-transform`}
          >
            <Icon className={`w-6 h-6 mx-auto mb-2 text-${color}-600`} />
            <div className={`text-3xl font-bold text-${color}-600`}>{value}</div>
            <div className="text-gray-600 dark:text-gray-300">{label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}