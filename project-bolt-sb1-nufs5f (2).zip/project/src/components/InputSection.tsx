import React from 'react';
import { Calculator } from 'lucide-react';

interface InputSectionProps {
  birthDate: string;
  onDateChange: (date: string) => void;
  onCalculate: () => void;
}

export function InputSection({ birthDate, onDateChange, onCalculate }: InputSectionProps) {
  const maxDate = new Date().toISOString().split('T')[0];

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 mb-8 transform hover:scale-[1.02] transition-transform">
      <div className="flex flex-col md:flex-row gap-4 items-center">
        <div className="flex-1 w-full">
          <label htmlFor="birthdate" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Enter your birth date
          </label>
          <input
            id="birthdate"
            type="date"
            max={maxDate}
            value={birthDate}
            onChange={(e) => onDateChange(e.target.value)}
            className="w-full p-3 rounded-lg border border-gray-300 dark:border-gray-600 dark:bg-gray-700 focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
          />
        </div>
        <button
          onClick={onCalculate}
          disabled={!birthDate}
          className="w-full md:w-auto px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg hover:opacity-90 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          <Calculator className="w-5 h-5" />
          Calculate Age
        </button>
      </div>
    </div>
  );
}