import React from 'react';
import { Heart, Activity, Baby, Hourglass, BarChart3, Sparkles } from 'lucide-react';
import type { AgeData } from '../types';

interface DetailedStatsProps {
  ageData: AgeData;
  showStats: boolean;
  onToggleStats: () => void;
  zodiacSign: string;
  lifeExpectancy: number;
}

export function DetailedStats({ ageData, showStats, onToggleStats, zodiacSign, lifeExpectancy }: DetailedStatsProps) {
  const stats = [
    {
      icon: Heart,
      label: 'Heartbeats',
      value: (ageData.years * 31536000 * 1.2).toLocaleString(),
      color: 'red',
    },
    {
      icon: Activity,
      label: 'Breaths Taken',
      value: (ageData.years * 31536000 * 16).toLocaleString(),
      color: 'green',
    },
    {
      icon: Baby,
      label: 'Zodiac Sign',
      value: zodiacSign,
      color: 'blue',
    },
    {
      icon: Hourglass,
      label: 'Life Progress',
      value: `${Math.round((ageData.years / lifeExpectancy) * 100)}%`,
      color: 'purple',
    },
  ];

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
      <button
        onClick={onToggleStats}
        className="w-full flex items-center justify-between p-2 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg transition-colors"
        aria-expanded={showStats}
      >
        <div className="flex items-center gap-2">
          <BarChart3 className="w-5 h-5 text-purple-600" />
          <span className="font-semibold">Detailed Statistics</span>
        </div>
        <Sparkles className={`w-5 h-5 text-yellow-500 transition-transform ${showStats ? 'rotate-180' : ''}`} />
      </button>

      {showStats && (
        <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4">
          {stats.map(({ icon: Icon, label, value, color }) => (
            <div key={label} className="stat-card transform hover:scale-105 transition-transform">
              <Icon className={`w-5 h-5 text-${color}-500`} />
              <div className="text-sm">{label}</div>
              <div className="font-bold">{value}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}