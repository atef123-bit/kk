export function calculateAge(birthDate: string): AgeData {
  const birth = new Date(birthDate);
  const now = new Date();
  
  const diffTime = Math.abs(now.getTime() - birth.getTime());
  
  return {
    years: Math.floor(diffTime / (1000 * 60 * 60 * 24 * 365.25)),
    months: Math.floor((diffTime % (1000 * 60 * 60 * 24 * 365.25)) / (1000 * 60 * 60 * 24 * 30.44)),
    days: Math.floor((diffTime % (1000 * 60 * 60 * 24 * 30.44)) / (1000 * 60 * 60 * 24)),
    hours: Math.floor((diffTime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
    minutes: Math.floor((diffTime % (1000 * 60 * 60)) / (1000 * 60)),
    seconds: Math.floor((diffTime % (1000 * 60)) / 1000),
  };
}

export function getZodiacSign(birthDate: string): ZodiacData {
  if (!birthDate) return { sign: '', element: '', traits: [] };
  
  const date = new Date(birthDate);
  const month = date.getMonth() + 1;
  const day = date.getDate();
  
  const zodiacData = {
    'Aries': { element: 'Fire', traits: ['Confident', 'Courageous', 'Enthusiastic'] },
    'Taurus': { element: 'Earth', traits: ['Patient', 'Reliable', 'Determined'] },
    'Gemini': { element: 'Air', traits: ['Adaptable', 'Versatile', 'Intellectual'] },
    'Cancer': { element: 'Water', traits: ['Emotional', 'Loving', 'Intuitive'] },
    'Leo': { element: 'Fire', traits: ['Creative', 'Passionate', 'Generous'] },
    'Virgo': { element: 'Earth', traits: ['Practical', 'Analytical', 'Meticulous'] },
    'Libra': { element: 'Air', traits: ['Diplomatic', 'Gracious', 'Fair-minded'] },
    'Scorpio': { element: 'Water', traits: ['Resourceful', 'Powerful', 'Brave'] },
    'Sagittarius': { element: 'Fire', traits: ['Optimistic', 'Philosophical', 'Straightforward'] },
    'Capricorn': { element: 'Earth', traits: ['Responsible', 'Disciplined', 'Self-controlled'] },
    'Aquarius': { element: 'Air', traits: ['Progressive', 'Original', 'Independent'] },
    'Pisces': { element: 'Water', traits: ['Compassionate', 'Artistic', 'Intuitive'] },
  };

  const signs = Object.keys(zodiacData);
  const cutoffDates = [20, 19, 20, 20, 20, 21, 22, 22, 22, 23, 22, 21];
  
  let signIndex = month - 1;
  if (day < cutoffDates[month - 1]) {
    signIndex = signIndex === 0 ? 11 : signIndex - 1;
  }
  
  const sign = signs[signIndex];
  return {
    sign,
    ...zodiacData[sign as keyof typeof zodiacData],
  };
}