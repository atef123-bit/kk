export interface AgeData {
  years: number;
  months: number;
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

export interface ZodiacData {
  sign: string;
  element: string;
  traits: string[];
}